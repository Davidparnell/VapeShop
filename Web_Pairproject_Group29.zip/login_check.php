<?php
	$errormsg = "";
	session_start();
	//Connect to the db and check if logged in
	$db = mysqli_connect("localhost","root","","groupproject");
	$username = $_POST['username'];
	$password = $_POST['password'];
	$result = mysqli_query($db,"select username from users where username = '$username' and password = '$password'");
    $numrows = mysqli_num_rows($result);
    
	if ($numrows == 1) { // one result indicates successful login
		$_SESSION['Login_Status'] = $username; //sets user session
        header("location: Home.php"); // redir
        echo "you've logged in";
	}
	else
	{
        $errormsg = "Incorrect User Name and Password";
        echo $errormsg;
	}
?>