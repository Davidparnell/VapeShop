<?php 
    //log out page
    session_start();
    $result = session_destroy(); //deleting the session, logout
    if($result) {
        header("Location: Home.php"); //goes to homepage
    }
?>