<?php
//if you click login/logout button on the right top of each page, it opens login.php
//if logged in, you're logged out and if you're not logged in, you see the login form
	$errormsg = $username = $password = "";
	session_start();
	
	if (isset($_SESSION['Login_Status'])) //Is logged in? - set button text
	{
        $login = "Logout";
        require "logout.php"; //if logged in, performs logout
	}
	else
	{
		$login = "Login";
	}
	
	//Connect to the db and check if logged in 
    require 'conn.php';
    if ($_SERVER["REQUEST_METHOD"] == "POST") { //if user clicks login button
        $username = $_POST['username'];
        $password = $_POST['password'];
        
        $check = "select username from users where username = '$username' and password = '$password'";
        $status=$con->query($check);
        
        $numrows = mysqli_num_rows($status);
        if ($numrows == 1) // one result indicates successful login
        {
            $_SESSION['Login_Status'] = $username;
            header("location: Home.php"); // redir
            echo "you've logged in";
        }
        else
        {
            $errormsg = "Incorrect User Name and Password";
        }
    }
?>

<html>
<head>
	<title>Vape Website</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" href="vapeShop.css">
	
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <script>
    </script>
</head>
<body>
	<header class="container-fluid text-center">
		<div class="container-fluid">
            <a href="Home.php" style="color: white; text-decoration: none"><h1>VAPE SHOP</h1></a>
		</div>
	</header>
	
	<!--Nav Bar-->
	<nav class="navbar navbar-inverse" style="border: none">
		<div class="container-fluid">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand glyphicon glyphicon-home" href="Home.php"></a>
			</div>
			<div class="collapse navbar-collapse" id="myNavbar">
				<ul class="nav navbar-nav">
					<li><a href="Products.php">Products</a></li>
					<li><a href="#aboutus">About Us</a></li>
				</ul>
				<div class="collapse navbar-collapse" id="myNavbar">
				<ul class="nav navbar-nav">
					 
				</ul>
				<ul class="nav navbar-nav navbar-right">
					<li><a href="Profile.php"><span class="glyphicon glyphicon-th-large"></span> My Page</a></li>
					<li><a href="Basket.php"><span class="glyphicon glyphicon-shopping-cart"></span> My Cart</a></li>
					<li><a href="login.php"><span class="glyphicon glyphicon-user"> <?php echo $login; ?></a></li></li>
					
					</div>
				</ul>
			</div>
		</div>
	</nav>
	
	<br>
	
	<div class="login">
		<form action = "login_check.php" method = "post" >
			<center><label>Username:</label><input type = "text" name = "username"/>
			<br/>
			<label>Password:</label><input type = "password" name = "password"/>
			<br/><br/>
            <button type="submit" class="btn btn-default" id="submit">Log in</button>
            <button class="btn btn-default"><a href="Register.php">Sign up</a></button>
			<br/>
			</center>
		</form>
	</div>
	
	<br>
	
	<footer class="container-fluid text-center">
		<h2 class="text-left" style="color:yellowgreen" id="aboutus">About us</h2>
		<div class="row">
			<div class="col-sm-4">
				<p style="padding:10px">
					8 Parker House Myrtle Court<br>
					The Coast, Baldoyle<br>
					Dublin 13, Ireland<br>
					<p >9am to 8pm</p>
				</p>
			</div>
			<div class="col-sm-4">
				<p style="font-size: 20px">Call Us On</p>
				<h3 style="color:yellowgreen">+353-1-495-2222</h3>
				<p>9am to 8pm</p>
				<p style="font-size: 15px">vapeshop.info@vapeshop.com</p>
			</div>
			<div class="col-sm-4">
				<img src="img/Footer/payment.jpg" class="img-responsive" style="width:100%; max-width: 200px;" alt="Image">
			</div>
		</div>
	</footer>

</body>
</html>