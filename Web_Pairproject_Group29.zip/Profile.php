<?php
//shows user information, can change user profile picture, cah change user's password
//if not logged in, redirects to login page
	session_start();
	$newPwd = $re_newPwd = "";
	if (isset($_SESSION['Login_Status'])) //Is logged in? - set button text
	{
		$login = "Logout";
	}
	else
	{
		$login = "Login";
	}
    if (isset($_SESSION['Login_Status'])){
        $uname = $_SESSION['Login_Status'];
		$name = $addr = $email = "";
		$pwdErr = "";

        require 'conn.php';
        //loading user information from DB
        $sql = "SELECT Username,Name,Address,Email FROM users WHERE Username LIKE '$uname'";
        $result = $con->query($sql);
    
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                $name = $row["Name"];
                $addr = $row["Address"];
                $email = $row["Email"];
            }
        }
        else {
            echo $uname;
            echo "0 results";
        }
		$con->close();
		
		// change password part
		$pwdSuccessful = 1;
		if ($_SERVER["REQUEST_METHOD"] == "POST"){ //if user clicks change password button
		if (isset($_POST['newPwd']) && isset($_POST['re_newPwd'])) {
			$newPwd = test_input($_POST["newPwd"]);
			$re_newPwd = test_input($_POST["re_newPwd"]);

			if (!preg_match("/^[0-9]*$/",$newPwd) || !preg_match("/^[0-9]*$/",$re_newPwd)) { 
				$pwdErr = "The password has to be digits only";
				$pwdSuccessful = 0;
			}
			else if(strcmp($newPwd, $re_newPwd) != 0) {//when the passwords are different
				$pwdErr = "This has to be the same as the first password.";
				$pwdSuccessful = 0;
			}
			if($pwdSuccessful) change_pwd($uname, $re_newPwd); //call change password functio
			//if the form was successfully done
		} }
    }
    else {
        header("Location: login.php");
    }
    function change_pwd($uname, $pwd) { //changing password
        require 'conn.php';
		$sql = "UPDATE users SET Password = $pwd WHERE Username = '$uname'";
        try {
			$con->query($sql);
			echo 'Your password has sucessfully changed.';
        } catch(Exception $e){
            echo 'Message: ' .$e->getMessage();
        }
		$con->close();
		
	}
	function test_input($data) {
		$data = trim($data);
		$data = stripslashes($data);
		$data = htmlspecialchars($data);
		return $data;
	}
?>
<html>
	<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<style>
		/* Add a gray background color and some padding to the footer */
		header {
      background-color: #212121;
      padding: 25px;
   	 }
		.btn-block {
			display: block;
			width: 100%;
			background-color: #101010;
		}
		.error { color: red; }
        .profile-pic {
            width:300px;
            height:300px;
            max-width: 100%;
            border-radius: 25px;
        }
	</style>
	<script src="path/to/jquery.js"></script>
	<script src="path/to/popper.js"></script>
	<script src="path/to/bootstrap.js"></script>
	<script src="path/to/bootstrap-confirmation.js"></script>
	<script>
	// $(document).ready(function(){
	// 		$("#data").fadeIn();
	// 	});
	</script>
</head>
	
<body>
	
	<!--Nav Bar-->
	<nav class="navbar navbar-inverse" style="border: none">
		<div class="container-fluid">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand glyphicon glyphicon-home" href="Home.php"></a>
			</div>
			<div class="collapse navbar-collapse" id="myNavbar">
				<ul class="nav navbar-nav">
					<li><a href="Products.php">Products</a></li>
					<li><a href="#aboutus">About Us</a></li>
				</ul>
				<div class="collapse navbar-collapse" id="myNavbar">
				<ul class="nav navbar-nav">
					 
				</ul>
				<ul class="nav navbar-nav navbar-right">
					<li><a href="Profile.php"><span class="glyphicon glyphicon-th-large"></span> My Page</a></li>
					<li><a href="Basket.php"><span class="glyphicon glyphicon-shopping-cart"></span> My Cart</a></li>
					<li><a href="login.php"><span class="glyphicon glyphicon-user"> <?php echo $login; ?></a></li></li>
					
					</div>
				</ul>
			</div>
		</div>
	</nav>
    
    <div class="row text-center" style="padding: 30px;"> <h1 style="color: yellowgreen;">Profile Page</h1><br></div>

    <div class="row">
        <div class="col-sm-1"></div>
        <div class="col-sm-3">
            <div class="row text-center">
				<!-- this loads 'username'.jpg image so 1 user has only 1 photo that is saved in the server -->
                <img class="profile-pic" src="img/uploads/<?php echo $_SESSION['Login_Status']; ?>.jpg" alt="mypic">
            </div>
            <br>
            <div class="row text-center">
                <form action="imageup.php" method="post" enctype="multipart/form-data"> <!--image upload form-->
                    <input type="file" style="float:right; padding: 3px;" name="fileToUpload" id="fileToUpload">
                    <input type="submit" class="btn btn-primary" value="Change Image">
                </form>
            </div>
            
        </div>
        <div class="col-sm-6" style="padding-left: 50px;" id="data">
            <h2>Hi, <b><?php echo $uname ?></b>!</h2>
            <h3>Name</h3>
            <p><?php echo $name ?></p>
            <h3>Address</h3>
            <p><?php echo $addr ?></p>
            <h3>Email</h3>
            <p><?php echo $email ?></p>
        </div>
        <div class="col-sm-2" style="padding-left: 50px;">
            <br><br>
			<br><br>
			<!-- change password form -->
			<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
				<div class="form-group">
					<label>Enter new password</label>
					<input type="password" name="newPwd" minlength="5" maxlength="10" placeholder="Enter your password, 5-10 numbers only" 
						value="<?php echo $newPwd ?>" class="form-control" required>
				</div>
				<div class="form-group">
					<label>Re-enter new password</label>
					<input type="password" name="re_newPwd" minlength="5" maxlength="10" placeholder="Re-enter your password, 5-10 numbers only" 
						value="<?php echo $re_newPwd ?>"class="form-control" id="re_password" required>
				</div>
				<span class="error"> <?php echo $pwdErr;?></span>
				<button type="submit" class="btn btn-danger">Change Password</button>
			</form>
        </div>
  </div>
  <div class="row text-center">
      
  </div>

    </body>
    </html>